/*
 * collaj_ffmpeg.c — host glue between fftools (FFmpegKitNext v8.1.1 flavour)
 * and Collaj's Swift plugin. Replaces FFmpegKitConfig.m: no Objective-C, no
 * sessions/queues/pipes/protocols, just what the app uses.
 *
 * Copyright (c) 2026 Arnaud Desné. MIT licence (this file only); it is built
 * into fftools.framework, which as a whole is LGPL-3.0-or-later.
 *
 * What fftools needs from its host (and nothing else, checked with nm -u):
 *   __thread long globalSessionId;          session of the current thread
 *   void cancelSession(long) / cancelAllSessions(void) / int cancelRequested(long)
 *   volatile int handleSIGQUIT, handleSIGINT, handleSIGTERM, handleSIGXCPU, handleSIGPIPE
 * What it exports and we call:
 *   int  ffmpeg_execute(int argc, char **argv)
 *   void set_report_callback(void (*)(int, float, float, int64_t, double, double, double))
 *   void ffmpegkit_report_write(void *, int, const char *, va_list)   (-report duty)
 */
#include "collaj_ffmpeg.h"

#include <inttypes.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libavutil/bprint.h"
#include "libavutil/display.h"
#include "libavutil/log.h"
#include "libavutil/pixdesc.h"

/* ------------------------------------------------ what fftools expects --- */
volatile int handleSIGQUIT = 0;   /* 0: fftools installs NO signal handler */
volatile int handleSIGINT  = 0;
volatile int handleSIGTERM = 0;
volatile int handleSIGXCPU = 0;
volatile int handleSIGPIPE = 0;
__thread long globalSessionId = 0;

/* Session ids are unique and increasing (the Dart side hands them out), so a
 * slot stores the id itself, never a state: a cancel requested BEFORE the
 * session starts is honoured when it starts, and a stale request can never
 * match a later session. (FFmpegKit stores 0/1/2 states and loses a cancel
 * that lands before its "running" mark.) */
#define SESSION_MAP_SIZE 1024
static atomic_long running_ids[SESSION_MAP_SIZE];   /* id running in the slot, 0 if none */
static atomic_long cancel_ids[SESSION_MAP_SIZE];    /* id whose cancel was requested */

void cancelSession(long id) {
    if (id > 0) atomic_store(&cancel_ids[id % SESSION_MAP_SIZE], id);
}
void cancelAllSessions(void) {
    for (int i = 0; i < SESSION_MAP_SIZE; i++) {
        long r = atomic_load(&running_ids[i]);
        if (r) atomic_store(&cancel_ids[i], r);
    }
}
int cancelRequested(long id) {
    return id > 0 && atomic_load(&cancel_ids[id % SESSION_MAP_SIZE]) == id;
}

int  ffmpeg_execute(int argc, char **argv);
void set_report_callback(void (*cb)(int, float, float, int64_t, double, double, double));
void ffmpegkit_report_write(void *ptr, int level, const char *fmt, va_list vl);

/* ----------------------------------------------------------- callbacks --- */
static collaj_log_cb   g_log_cb;
static collaj_stats_cb g_stats_cb;
static void           *g_opaque;
static __thread int    t_print_prefix = 1;

static void log_callback(void *avcl, int level, const char *fmt, va_list vl) {
    va_list copy;
    va_copy(copy, vl);
    ffmpegkit_report_write(avcl, level, fmt, copy);   /* no-op unless -report */
    va_end(copy);

    if (level >= 0) level &= 0xff;
    if (level > av_log_get_level() || !g_log_cb) return;

    char line[2048];
    /* Public API; formats "[h264 @ 0x...] message" exactly like the CLI. */
    av_log_format_line2(avcl, level, fmt, vl, line, sizeof(line), &t_print_prefix);
    if (line[0]) g_log_cb(globalSessionId, level, line, g_opaque);
}

static void report_callback(int frame, float fps, float quality, int64_t size,
                            double time_ms, double bitrate, double speed) {
    if (g_stats_cb)
        g_stats_cb(globalSessionId, frame, fps, quality, size, time_ms, bitrate, speed, g_opaque);
}

void collaj_ffmpeg_init(collaj_log_cb log_cb, collaj_stats_cb stats_cb, void *opaque) {
    g_log_cb = log_cb;
    g_stats_cb = stats_cb;
    g_opaque = opaque;
    av_log_set_callback(log_callback);
    set_report_callback(report_callback);
}

void collaj_ffmpeg_set_log_level(int level) { av_log_set_level(level); }
int  collaj_ffmpeg_get_log_level(void) { return av_log_get_level(); }

/* ------------------------------------------------------------- execute --- */
int collaj_ffmpeg_execute(long session_id, int argc, const char *const *argv) {
    if (session_id <= 0) return 1;
    char **args = calloc((size_t)argc + 2, sizeof(char *));
    if (!args) return 1;
    args[0] = "ffmpeg";
    for (int i = 0; i < argc; i++) args[i + 1] = (char *)argv[i];

    const int slot = (int)(session_id % SESSION_MAP_SIZE);
    int rc = COLLAJ_RC_CANCEL;
    if (!cancelRequested(session_id)) {            /* cancelled before it started */
        globalSessionId = session_id;
        atomic_store(&running_ids[slot], session_id);
        t_print_prefix = 1;
        rc = ffmpeg_execute(argc + 1, args);
        long expected = session_id;
        atomic_compare_exchange_strong(&running_ids[slot], &expected, 0);
        globalSessionId = 0;
    }
    long expected = session_id;
    atomic_compare_exchange_strong(&cancel_ids[slot], &expected, 0);
    free(args);
    return rc;
}

void collaj_ffmpeg_cancel(long session_id) { if (session_id > 0) cancelSession(session_id); }
void collaj_ffmpeg_cancel_all(void) { cancelAllSessions(); }

/* ---------------------------------------------------------------- probe --- */
static void json_str(AVBPrint *b, const char *s) {
    av_bprint_chars(b, '"', 1);
    for (const unsigned char *p = (const unsigned char *)(s ? s : ""); *p; p++) {
        switch (*p) {
        case '"':  av_bprintf(b, "\\\""); break;
        case '\\': av_bprintf(b, "\\\\"); break;
        case '\n': av_bprintf(b, "\\n");  break;
        case '\r': av_bprintf(b, "\\r");  break;
        case '\t': av_bprintf(b, "\\t");  break;
        default:
            if (*p < 0x20) av_bprintf(b, "\\u%04x", *p);
            else av_bprint_chars(b, (char)*p, 1);
        }
    }
    av_bprint_chars(b, '"', 1);
}
static void kv_str(AVBPrint *b, int *first, const char *k, const char *v) {
    if (!v) return;
    av_bprintf(b, "%s\"%s\":", *first ? "" : ",", k); *first = 0; json_str(b, v);
}
static void kv_int(AVBPrint *b, int *first, const char *k, int64_t v) {
    av_bprintf(b, "%s\"%s\":%" PRId64, *first ? "" : ",", k, v); *first = 0;
}
static void kv_q(AVBPrint *b, int *first, const char *k, AVRational q) {
    char s[64]; snprintf(s, sizeof(s), "%d/%d", q.num, q.den); kv_str(b, first, k, s);
}
static void kv_secs(AVBPrint *b, int *first, const char *k, int64_t ts, AVRational tb) {
    if (ts == AV_NOPTS_VALUE) return;
    char s[64]; snprintf(s, sizeof(s), "%f", ts * av_q2d(tb)); kv_str(b, first, k, s);   /* ffprobe prints strings */
}
static void tags(AVBPrint *b, int *first, const AVDictionary *d) {
    const AVDictionaryEntry *e = NULL;
    if (!av_dict_count(d)) return;
    av_bprintf(b, "%s\"tags\":{", *first ? "" : ","); *first = 0;
    int f = 1;
    while ((e = av_dict_iterate(d, e))) kv_str(b, &f, e->key, e->value);
    av_bprintf(b, "}");
}

char *collaj_probe_json(long session_id, const char *path, char *err, size_t err_len) {
    AVFormatContext *fc = NULL;
    long saved = globalSessionId;
    globalSessionId = session_id;           /* route the demuxer's warnings */
    int ret = avformat_open_input(&fc, path, NULL, NULL);
    if (ret >= 0) ret = avformat_find_stream_info(fc, NULL);
    if (ret < 0) {
        if (err && err_len) av_strerror(ret, err, err_len);
        avformat_close_input(&fc);
        globalSessionId = saved;
        return NULL;
    }
    AVBPrint b;
    av_bprint_init(&b, 0, AV_BPRINT_SIZE_UNLIMITED);
    av_bprintf(&b, "{\"streams\":[");
    for (unsigned i = 0; i < fc->nb_streams; i++) {
        const AVStream *st = fc->streams[i];
        const AVCodecParameters *par = st->codecpar;
        int f = 1;
        av_bprintf(&b, "%s{", i ? "," : "");
        kv_int(&b, &f, "index", st->index);
        kv_str(&b, &f, "codec_type", av_get_media_type_string(par->codec_type));
        kv_str(&b, &f, "codec_name", avcodec_get_name(par->codec_id));   /* "none" when unknown */
        av_bprintf(&b, ",\"decodable\":%s", avcodec_find_decoder(par->codec_id) ? "true" : "false");
        if (par->codec_type == AVMEDIA_TYPE_VIDEO) {
            kv_int(&b, &f, "width", par->width);
            kv_int(&b, &f, "height", par->height);
            kv_str(&b, &f, "pix_fmt", av_get_pix_fmt_name(par->format));
            kv_str(&b, &f, "color_range", av_color_range_name(par->color_range));
            kv_str(&b, &f, "color_space", av_color_space_name(par->color_space));
            kv_str(&b, &f, "color_transfer", av_color_transfer_name(par->color_trc));
            kv_str(&b, &f, "color_primaries", av_color_primaries_name(par->color_primaries));
            const AVPacketSideData *sd = av_packet_side_data_get(par->coded_side_data,
                par->nb_coded_side_data, AV_PKT_DATA_DISPLAYMATRIX);
            if (sd && sd->size >= 9 * sizeof(int32_t)) {
                double r = av_display_rotation_get((const int32_t *)sd->data);
                if (r == r) kv_int(&b, &f, "rotation", (int64_t)(r < 0 ? r - 0.5 : r + 0.5));
            }
        } else if (par->codec_type == AVMEDIA_TYPE_AUDIO) {
            { char sr[16]; snprintf(sr, sizeof(sr), "%d", par->sample_rate); kv_str(&b, &f, "sample_rate", sr); }  /* a string, as ffprobe prints it */
            kv_int(&b, &f, "channels", par->ch_layout.nb_channels);
        }
        kv_q(&b, &f, "r_frame_rate", st->r_frame_rate);
        kv_q(&b, &f, "avg_frame_rate", st->avg_frame_rate);
        kv_q(&b, &f, "time_base", st->time_base);
        kv_secs(&b, &f, "duration", st->duration, st->time_base);
        if (st->nb_frames > 0) { char s[32]; snprintf(s, sizeof(s), "%" PRId64, st->nb_frames); kv_str(&b, &f, "nb_frames", s); }
        if (par->bit_rate > 0) { char s[32]; snprintf(s, sizeof(s), "%" PRId64, par->bit_rate); kv_str(&b, &f, "bit_rate", s); }
        tags(&b, &f, st->metadata);
        av_bprintf(&b, "}");
    }
    int f = 1;
    av_bprintf(&b, "],\"format\":{");
    kv_str(&b, &f, "filename", path);
    kv_str(&b, &f, "format_name", fc->iformat ? fc->iformat->name : NULL);
    kv_int(&b, &f, "nb_streams", fc->nb_streams);
    kv_secs(&b, &f, "duration", fc->duration, AV_TIME_BASE_Q);
    if (fc->bit_rate > 0) { char s[32]; snprintf(s, sizeof(s), "%" PRId64, fc->bit_rate); kv_str(&b, &f, "bit_rate", s); }
    tags(&b, &f, fc->metadata);
    av_bprintf(&b, "}}");
    avformat_close_input(&fc);
    globalSessionId = saved;

    char *out = NULL;
    if (!av_bprint_is_complete(&b) || av_bprint_finalize(&b, &out) < 0) return NULL;
    /* av_bprint_finalize allocates with av_malloc: hand back a malloc'ed copy. */
    size_t n = strlen(out) + 1;
    char *copy = malloc(n);           /* not strdup: stays valid under strict -std=c17 */
    if (copy) memcpy(copy, out, n);
    av_free(out);
    return copy;
}

void collaj_free(void *p) { free(p); }
