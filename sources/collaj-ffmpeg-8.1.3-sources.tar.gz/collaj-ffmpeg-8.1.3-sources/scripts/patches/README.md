# Correctifs de FFmpeg — APPLIQUÉS depuis le 08/11/2026 (vote O4 d'Arnaud)

Écrits pour FFmpeg 8.1.2 (la 2.0) ; FFmpeg 8.1.3 depuis le 12/11/2026 (2.0.1) : `0001` s'y applique tel quel
(`libavfilter/vf_scale_vt.c` est identique dans les deux versions). À chaque nouvelle version de FFmpeg, vérifier
que chaque correctif s'applique encore (`patch -p1 --dry-run`) avant de compiler.

`build_ffmpeg_ios.sh` compile FFmpeg à partir d'une copie de l'archive officielle (en lecture seule) sur laquelle il
applique `patches/*.patch` (`patch -p1`) : c'est le FFmpeg que l'app embarque depuis la 2.0 (vote O4 de
`docs/debriefs/2026-11-08-optimisation.html`, « Oui, avant la 2.0 »). `COLLAJ_FFMPEG_PATCHES=0` recompile l'archive
intacte, pour comparer.

Les correctifs partent dans les sources publiées (`out/SOURCES/…/changes.diff` et `scripts/patches/`, et la notice
`SOURCES.md` le dit), à publier avec l'app (licence LGPL, dépôt collaj-legal, `publish_sources.py`). Après une
compilation : `packages/collaj_ffmpeg/tool/sync_frameworks.py`, et `ExportShipped.chipEightBit` dans l'app.

## 0001-scale_vt-format-option.patch (08/11/2026)

Ajoute à `scale_vt` une option `format` : la puce rend ses images dans ce format (VideoToolbox convertit), au lieu
du format d'entrée. Pour une vidéo HDR (10 bits) exportée en SDR, `scale_vt=...:format=nv12` sort du 8 bits : le
processeur n'a plus à ramener chaque image de 10 à 8 bits (le plus gros coût restant de la passe 1 pour une vidéo
d'iPhone, presque toutes en HDR).

Mesuré le 08/11 sur le Mac (M3 Pro), FFmpeg 8.1.2 compilé avec ce correctif, 20 s de la vidéo HDR longue, un fil
de filtre : 1080 : 9,8 s → 2,5 s ; 4K : 37,5 s → 10,4 s. Image : SSIM 0,994, PSNR 47,6 dB contre la conversion
par le processeur (arrondi de la puce, sans tramage).

Idée voisine, sans correctif : activer `transpose_vt` (déjà dans FFmpeg 8.1.2) dans `configure_flags.txt`, pour
tourner sur la puce les vidéos filmées en portrait.

## 0002-overlay-aarch64-neon.patch (15/11/2026)

Le filtre `overlay` — tous les calques de l'assemblage : chaque case, le calque des bordures, chaque sticker, chaque
texte — n'a de code rapide que pour les processeurs Intel (`libavfilter/x86/`). Sur iPhone, chaque pixel de chaque
calque est mélangé en C, à chaque image. Ce correctif ajoute le mélange NEON du chemin 4:2:0 8 bits à alpha droit,
image principale sans alpha. Il est rétroporté tel quel du 2ᵉ commit de la
[PR #23633 de FFmpeg](https://code.ffmpeg.org/FFmpeg/FFmpeg/pulls/23633) (Damitha Gunawardena, en relecture en
amont, pas encore fusionnée au 15/11) ; le 1ᵉʳ commit (branchement de checkasm côté x86) n'est pas repris.

Vérifié le 15/11 : mêmes octets que le code C sur le Mac (FFmpeg 8.1.3 compilé avec et sans, graphes réels de
l'app et graphe de torture : alpha aléatoire, calques à cheval sur les bords) ; sur l'iPhone 17 Pro, 22 exports
identiques au bit, image par image, entre l'ancien FFmpeg et celui-ci. Assemblage sur l'iPhone, 1080 : cadre
polaroid 2,3 → 1,5 s, texte fixe 2,0 → 1,5 s, 3 emoji en 4K 12,8 → 9,0 s.

## 0003-overlay-aarch64-neon-10bit.patch (15/11/2026)

Le même mélange pour le chemin 10 bits (`yuv420p10`, l'assemblage d'un export HDR), que 0002 ne couvre pas : écrit
pour Collaj en intrinsèques NEON. Le code C divise par 1023 ; `x / 1023 == (x + 1 + (x >> 10)) >> 10` pour tout
x jusqu'à 1023 × 1023 (vérifié exhaustivement), donc mêmes échantillons. `blend_plane` n'exige plus 8 bits pour
appeler `blend_row` : le crochet n'est posé que pour la profondeur de l'instance.

## 0004-overlay-main-alpha-rows-and-race.patch (15/11/2026)

Pour une image principale qui a un plan alpha (`yuva420p`) — une case de plusieurs clips, donc tout Diaporama :

1. **Une course entre fils corrigée**, présente dans FFmpeg tel qu'il sort (vue en 8.1.3 et en 9.0.1). En 4:2:0, la
   chroma lit l'alpha de l'image principale sur deux lignes ; les tâches ne coupent pas les plans aux mêmes lignes,
   et chacune réécrit l'alpha juste après ses couleurs : une tâche pouvait réécrire un alpha qu'une autre lisait
   encore. À plusieurs fils, la sortie changeait d'un passage à l'autre (4 passages, 4 sorties) ; à un fil, jamais.
   `do_blend` fait désormais les couleurs de toutes les tranches, puis l'alpha de toutes les tranches : la sortie
   d'un seul fil, quel que soit le nombre de fils. À signaler en amont.
2. **Vitesse** : là où le calque est opaque sur tout un bloc le mélange est une copie, là où il est transparent il
   n'y a rien à faire ; les blocs sont triés en NEON, les autres passent par l'arithmétique du code C, échantillon
   par échantillon ; en 8 bits et en 10 bits (Diaporamas HDR). Diaporama de 10 médias en 1080, graphe de l'assemblage sur un fil (Mac M3 Pro) : 17,3 s de
   processeur tel que sorti, 15,1 s avec 0002, 10,8 s avec 0004 ; mêmes images à l'octet.

## 0005-paletteuse-direct-colour-table.patch (15/11/2026)

`paletteuse` (la mise en palette d'un GIF) garde chaque couleur déjà cherchée dans 32 768 listes relues depuis leur
début. Avec un tramage par diffusion d'erreur (`sierra2_4a`, celui de l'export GIF de Collaj), une vidéo fait des
millions de couleurs : chaque pixel parcourt des centaines d'entrées, 16 s d'un export GIF de 22 sur l'iPhone 17 Pro.
Le correctif garde la réponse de chaque couleur opaque dans une table indexée par ses 24 bits (16 Mo + 2 Mo, allouée
à la première couleur opaque ; sans la mémoire, les listes servent comme avant). La recherche est la même, seul
l'endroit où sa réponse est gardée change : **GIF identique à l'octet** (`sierra2_4a`, `floyd_steinberg`, `bayer`,
`none`), 18,2 s → 7,8 s sur le Mac (315 images de 480 × 854). À proposer en amont.

Chaque correctif part dans les sources publiées (LGPL) : à republier avant toute sortie qui embarque ce FFmpeg.
