# Correctifs de FFmpeg 8.1.2 — APPLIQUÉS depuis le 08/11/2026 (vote O4 d'Arnaud)

`build_ffmpeg_ios.sh` compile FFmpeg à partir d'une copie de l'archive officielle (en lecture seule) sur laquelle il
applique `patches/*.patch` (`patch -p1`) : c'est le FFmpeg que l'app embarque depuis la 2.0 (vote O4 de
`docs/debriefs/2026-11-08-optimisation.html`, « Oui, avant la 2.0 »). `COLLAJ_FFMPEG_PATCHES=0` recompile l'archive
intacte, pour comparer.

Les correctifs partent dans les sources publiées (`out/SOURCES/…/changes.diff` et `scripts/patches/`, et la notice
`SOURCES.md` le dit), à publier avec l'app (licence LGPL, dépôt collaj-legal, `publish_sources.py`). Après une
compilation : `packages/collaj_ffmpeg/tool/sync_frameworks.py`, et `ExportShipped.chipEightBit` dans l'app.

## 0001-scale_vt-format-option.patch (08/11/2026)

Ajoute à `scale_vt` une option `format` : la puce rend ses images dans ce format (VideoToolbox convertit), au lieu
du format d'entrée. Pour une vidéo HDR (10 bits) exportée en SDR, `scale_vt=...:format=nv12` sort du 8 bits : le
processeur n'a plus à ramener chaque image de 10 à 8 bits (le plus gros coût restant de la passe 1 pour une vidéo
d'iPhone, presque toutes en HDR).

Mesuré le 08/11 sur le Mac (M3 Pro), FFmpeg 8.1.2 compilé avec ce correctif, 20 s de la vidéo HDR longue, un fil
de filtre : 1080 : 9,8 s → 2,5 s ; 4K : 37,5 s → 10,4 s. Image : SSIM 0,994, PSNR 47,6 dB contre la conversion
par le processeur (arrondi de la puce, sans tramage).

Idée voisine, sans correctif : activer `transpose_vt` (déjà dans FFmpeg 8.1.2) dans `configure_flags.txt`, pour
tourner sur la puce les vidéos filmées en portrait.
