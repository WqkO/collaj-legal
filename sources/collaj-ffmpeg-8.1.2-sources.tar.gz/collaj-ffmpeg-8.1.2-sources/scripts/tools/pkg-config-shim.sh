#!/bin/sh
# Minimal pkg-config replacement for FFmpeg's configure.
#
# Xcode does not ship pkg-config and the build must not depend on Homebrew,
# so this answers exactly the calls FFmpeg's configure makes
# (test_pkg_config / check_pkg_config in configure):
#   --version
#   --exists [--print-errors] "<pkg> [op version]"
#   --cflags [--static] <pkg>
#   --libs   [--static] <pkg>
#   --variable=<name> <pkg>
#   --modversion <pkg>
# .pc files are looked up in $PKG_CONFIG_LIBDIR (colon-separated), nothing else.
# Version constraints are not checked: the versions are pinned by the build script.
# Licence: MIT (part of Collaj's build scripts).

mode=""; static=0; var=""; pkg=""
for a in "$@"; do
  case "$a" in
    --version) echo "0.29.2-collaj-shim"; exit 0 ;;
    --exists|--cflags|--libs|--modversion) mode="${a#--}" ;;
    --variable=*) mode="variable"; var="${a#--variable=}" ;;
    --static) static=1 ;;
    --print-errors|--short-errors|--silence-errors) ;;
    -*) ;;
    *) [ -z "$pkg" ] && pkg="${a%% *}" ;;   # "zimg >= 2.7.0" -> "zimg"
  esac
done
[ -n "$pkg" ] || { echo "pkg-config-shim: no package given" >&2; exit 1; }

pcfile=""
IFS_SAVE="$IFS"; IFS=":"
for d in ${PKG_CONFIG_LIBDIR:-}; do
  if [ -f "$d/$pkg.pc" ]; then pcfile="$d/$pkg.pc"; break; fi
done
IFS="$IFS_SAVE"
if [ -z "$pcfile" ]; then
  echo "Package $pkg was not found in the pkg-config search path ($PKG_CONFIG_LIBDIR)" >&2
  exit 1
fi
[ "$mode" = "exists" ] && exit 0

awk -v mode="$mode" -v static="$static" -v want="$var" '
  function expand(s,   out, name, i) {
    while (match(s, /\$\{[A-Za-z0-9_.]+\}/)) {
      name = substr(s, RSTART + 2, RLENGTH - 3)
      s = substr(s, 1, RSTART - 1) vars[name] substr(s, RSTART + RLENGTH)
    }
    return s
  }
  /^[ \t]*#/ || /^[ \t]*$/ { next }
  /^[A-Za-z0-9_.]+=/ { i = index($0, "="); vars[substr($0, 1, i - 1)] = expand(substr($0, i + 1)); next }
  /^[A-Za-z0-9_.]+:/ { i = index($0, ":"); v = substr($0, i + 1); sub(/^[ \t]+/, "", v); fields[substr($0, 1, i - 1)] = expand(v); next }
  END {
    if (mode == "cflags")       print fields["Cflags"]
    else if (mode == "libs")    print fields["Libs"] (static ? " " fields["Libs.private"] : "")
    else if (mode == "variable") print vars[want]
    else if (mode == "modversion") print fields["Version"]
  }' "$pcfile"
