/*
 * collaj_ffmpeg.h — the C API of fftools.framework.
 *
 * fftools.framework is a DYNAMIC framework that contains:
 *   - FFmpeg's command-line tool (fftools/ffmpeg*.c, cmdutils.c, opt_common.c,
 *     sync_queue.c, thread_queue.c, graph/, textformat/, resources/), in the
 *     version adapted to run as a library by FFmpegKitNext v8.1.1 (tag v8.1.1,
 *     derived from FFmpeg n8.1.2, LGPL-3.0-or-later), with ffmpeg_context.c;
 *   - this glue (collaj_ffmpeg.c, MIT), which replaces FFmpegKitConfig.m.
 * It links dynamically to libavutil, libavcodec, libavformat, libavfilter,
 * libswscale and libswresample.frameworks. Its complete source is published
 * with the FFmpeg source (see SOURCES.md).
 *
 * The app's own Swift plugin (statically linked, not LGPL) only calls the
 * functions below.
 *
 * Threading: collaj_ffmpeg_execute() and collaj_probe_json() block; call them
 * from a worker thread. Any number of sessions may run at once (fftools state
 * is thread-local per session, propagated to fftools' own worker threads by
 * ffmpeg_context.c). Callbacks arrive on FFmpeg's threads: copy what you need
 * and return quickly; never call back into FFmpeg from a callback.
 */
#ifndef COLLAJ_FFMPEG_H
#define COLLAJ_FFMPEG_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Return codes of collaj_ffmpeg_execute (same meaning as FFmpegKit's ReturnCode). */
#define COLLAJ_RC_SUCCESS 0
#define COLLAJ_RC_CANCEL  255

/*
 * One formatted log line. session_id is the session whose thread logged it,
 * or 0 when the line came from a thread that belongs to no session (codec
 * frame threads, VideoToolbox callback queues). The caller decides what to do
 * with 0 lines; the Swift bridge hands them to every live session, which is
 * right for the VideoToolbox-invalidated signatures the app watches for
 * (an invalidation hits every hardware session at once).
 */
typedef void (*collaj_log_cb)(long session_id, int level, const char *line, void *opaque);

/*
 * Progress, from fftools' print_report() on the session's main thread,
 * every -stats_period (0.5 s by default) and once at the end.
 * time_ms is the output timestamp in milliseconds.
 */
typedef void (*collaj_stats_cb)(long session_id, int frame, float fps, float quality,
                                int64_t size, double time_ms, double bitrate_kbps,
                                double speed, void *opaque);

/* Installs the two callbacks (process-wide, once) and turns off fftools'
 * signal handlers (an app must keep SIGINT/SIGTERM/SIGPIPE to itself). */
void collaj_ffmpeg_init(collaj_log_cb log_cb, collaj_stats_cb stats_cb, void *opaque);

/* av_log level (AV_LOG_WARNING = 24, AV_LOG_INFO = 32...). Process-wide. */
void collaj_ffmpeg_set_log_level(int level);
int  collaj_ffmpeg_get_log_level(void);

/*
 * Runs one ffmpeg command, blocking. argv does NOT include the program name
 * ("-i", "in.mov", ..., "-y", "out.mp4"). session_id must be > 0 and unique
 * among running sessions. Returns fftools' exit code: 0 success, 255 cancelled,
 * anything else failure.
 */
int collaj_ffmpeg_execute(long session_id, int argc, const char *const *argv);

/* Asks a session to stop; it returns 255 shortly after — within the 0.5 s its
 * main loop sleeps, even when an input loops for ever (-stream_loop -1) — and
 * its log lines stop at once. Works before the session starts too (it then
 * returns 255 at once). Ids must be unique and increasing. */
void collaj_ffmpeg_cancel(long session_id);
void collaj_ffmpeg_cancel_all(void);

/*
 * Media information, without ffprobe: libavformat's own parse, as JSON with the
 * keys FFprobe's -show_format -show_streams uses (format.tags, streams[].
 * codec_type, codec_name, width, height, pix_fmt, color_transfer, color_primaries,
 * avg_frame_rate, r_frame_rate, time_base, duration, nb_frames, tags...),
 * plus two keys ffprobe does not have:
 *   streams[].decodable  true only if THIS build has a decoder for the stream
 *                        (the app picks "the first audio track FFmpeg can
 *                        decode": with a trimmed decoder list, a known codec
 *                        name is no longer proof);
 *   streams[].rotation   display-matrix rotation in degrees, when present.
 * Returns a malloc'ed NUL-terminated string (free with collaj_free), or NULL
 * with a message in err.
 */
char *collaj_probe_json(long session_id, const char *path, char *err, size_t err_len);
void  collaj_free(void *p);

#ifdef __cplusplus
}
#endif
#endif /* COLLAJ_FFMPEG_H */
