#!/usr/bin/env bash
# =============================================================================
# build_ffmpeg_ios.sh — Collaj's own minimal FFmpeg for iOS, LGPL v2.1+.
#
# ONE COMMAND, on the Mac, with Xcode 26 or 27 installed and nothing else
# (no Homebrew, no Nix, no pkg-config, no nasm, no autotools). The only tools
# that do not come with Xcode are meson and ninja, which dav1d needs: they are
# pip-installed at pinned versions (SHA-256 checked wheels) into a venv made
# with Xcode's own python3, inside $WORK.
#
#     ./build_ffmpeg_ios.sh
#
# It downloads four pinned source tarballs (SHA-256 checked), builds
#   zimg 3.0.6 (static)  ->  linked into libavfilter   (WTFPL)
#   OpenH264 2.6.0 (static) -> linked into libavcodec  (BSD-2-Clause)
#   dav1d 1.5.4 (static)  ->  linked into libavcodec   (BSD-2-Clause, AV1 decoding)
#   FFmpeg 8.1.2 with configure_flags.txt (the [apple] lines included)
# for two slices (iPhone arm64, simulator arm64 — add ios-x86_64-simulator to
# SLICES for an Intel Mac), turns each
# FFmpeg library into a DYNAMIC framework (@rpath install names, Info.plist,
# MinimumOSVersion) and packs them as .xcframeworks, with dSYMs.
# It also builds fftools.xcframework (the ffmpeg command-line tool as a
# library + bridge/native/collaj_ffmpeg.c), which the app's bridge runs.
# Finally it assembles out/SOURCES/: every tarball, this script, the flags,
# the helper, the toolchain versions and the configure line, i.e. the
# "Corresponding Source" to publish next to the app.
#
# Idempotent and resumable: each step leaves a stamp that records its inputs;
# re-running skips what is done and redoes what changed (edit
# configure_flags.txt => FFmpeg is rebuilt, zimg/OpenH264/dav1d are not).
# Zero interaction. Logs: $WORK/logs/. Exit code != 0 on any failure, with the
# tail of the failing log printed.
#
# Knobs (environment variables):
#   IOS_MIN=16.0        deployment target (Runner's IPHONEOS_DEPLOYMENT_TARGET)
#   SLICES="ios-arm64 ios-arm64-simulator"   (+ ios-x86_64-simulator: Intel Mac)
#   WORK=/tmp/collaj-ffmpeg-build   build tree (fixed path: no user name in binaries)
#   OUT=<script dir>/out            results
#   JOBS=<number of cores>
#   DSYM=1              keep debug info as .dSYM bundles (0: no dSYM)
#   SMALL=0             1 = --enable-small (smaller, slower; today's package uses it)
#   FFTOOLS=1           0 = skip fftools.xcframework (the libraries alone)
#   BUNDLE_ID_PREFIX=com.arnaud.collaj.ffmpeg
#   CLEAN=1             wipe $WORK first
#   PYTHON3=python3     the python used for the meson/ninja venv (Xcode's /usr/bin/python3)
#   COLLAJ_FFMPEG_PATCHES=1  build FFmpeg with patches/*.patch applied to a copy of its sources, and
#                       publish them in the sources' changes.diff (see patches/README.md): what the app ships
#                       since 08/11/2026 (Arnaud's vote O4). 0: the release tarball as it is, for comparisons.
#
# Licence of this script: MIT. Copyright (c) 2026 Arnaud Desné.
# =============================================================================
# Written for the bash 3.2 that macOS ships (/bin/bash): no mapfile, no wait -n,
# and every possibly-empty array is expanded as ${a[@]+"${a[@]}"} (set -u).
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_REV=1          # bump to force a full rebuild after editing this script
PATCHES_DIR="$SCRIPT_DIR/patches"
FFSRC=""              # FFmpeg's sources as built: set by ffmpeg_sources
PATCHES_KEY=""        # the patches applied, hashed; empty without COLLAJ_FFMPEG_PATCHES=1

# ------------------------------------------------------------- pinned sources
FFMPEG_VERSION=8.1.2
FFMPEG_URL="https://ffmpeg.org/releases/ffmpeg-${FFMPEG_VERSION}.tar.xz"
FFMPEG_SHA256=464beb5e7bf0c311e68b45ae2f04e9cc2af88851abb4082231742a74d97b524c
FFMPEG_ASC_SHA256=0a0963fccd70597838073f3e31b20f4a4d8cc2b5e577472c9a5a1f22624246f8   # FFmpeg release signature, published with the sources
ZIMG_VERSION=3.0.6
ZIMG_URL="https://github.com/sekrit-twc/zimg/archive/refs/tags/release-${ZIMG_VERSION}.tar.gz"
ZIMG_SHA256=be89390f13a5c9b2388ce0f44a5e89364a20c1c57ce46d382b1fcc3967057577
OPENH264_VERSION=2.6.0
OPENH264_URL="https://github.com/cisco/openh264/archive/refs/tags/v${OPENH264_VERSION}.tar.gz"
OPENH264_SHA256=558544ad358283a7ab2930d69a9ceddf913f4a51ee9bf1bfb9e377322af81a69
DAV1D_VERSION=1.5.4       # latest 1.5.x (released 2026-07-14)
DAV1D_URL="https://downloads.videolan.org/pub/videolan/dav1d/${DAV1D_VERSION}/dav1d-${DAV1D_VERSION}.tar.xz"
DAV1D_SHA256=686616b7c69eb88d44459391ab25cac13b6647a3b288835c5784e71c1514a5c5      # = VideoLAN's .sha256 file
DAV1D_ASC_SHA256=b7e9664c8d847b2e88b059843b9977a74df2a7c7d911b094821dc236671bf9fc  # release signature, published too
# Build tools for dav1d, from PyPI, hash-pinned (pip --require-hashes).
# meson 1.11.2 = the newest meson that still runs on Python 3.7+ (1.12 needs 3.10,
# and Xcode's python3 may be older); ninja 1.13.2 ships a macOS universal2 wheel.
MESON_VERSION=1.11.2
MESON_WHL_SHA256=7e4f6e83fec83e3eaac928e058b073c7557b282c35b6a2024cea143a39926a39              # meson-1.11.2-py3-none-any.whl
NINJA_VERSION=1.13.2
NINJA_WHL_SHA256_MAC=fd82e26c0706ad4ab88e5fdd26f3fab0a987a90f810160f6c322e752c6af298b          # ninja-1.13.2-py3-none-macosx_10_9_universal2.whl
NINJA_WHL_SHA256_LINUX_ARM64=d775a5e43e9088f507a6250d57fcf5678eb31268c545feb5064ffeee33735622  # manylinux aarch64 wheel (Linux trial)
# Only with FFTOOLS=1: fftools adapted to run as a library (LGPL-3.0-or-later).
FFKIT_NEXT_VERSION=8.1.1
FFKIT_NEXT_URL="https://github.com/arthenica/ffmpeg-kit-next/archive/refs/tags/v${FFKIT_NEXT_VERSION}.tar.gz"
FFKIT_NEXT_SHA256=9afcf3422921e67c7cf0950940509bc956d79fd311d3ac3592ba10fe6cfd3787

# ------------------------------------------------------------------- settings
IOS_MIN="${IOS_MIN:-16.0}"
SLICES="${SLICES:-ios-arm64 ios-arm64-simulator}"
WORK="${WORK:-/tmp/collaj-ffmpeg-build}"
OUT="${OUT:-$SCRIPT_DIR/out}"
JOBS="${JOBS:-$(sysctl -n hw.ncpu 2>/dev/null || echo 8)}"
DSYM="${DSYM:-1}"
SMALL="${SMALL:-0}"
FFTOOLS="${FFTOOLS:-1}"
PYTHON3="${PYTHON3:-python3}"
BUNDLE_ID_PREFIX="${BUNDLE_ID_PREFIX:-com.arnaud.collaj.ffmpeg}"
FLAGS_FILE="$SCRIPT_DIR/configure_flags.txt"
SHIM="$SCRIPT_DIR/tools/pkg-config-shim.sh"
LIBS=(libavutil libswresample libswscale libavcodec libavformat libavfilter)   # dependency order

LOGS="$WORK/logs"; STAMPS="$WORK/stamps"; DL="$WORK/downloads"; SRC="$WORK/src"
T0=$(date +%s)
CURRENT_LOG=""

say()  { printf '[%4ds] %s\n' "$(( $(date +%s) - T0 ))" "$*"; }
die()  { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
on_err() {
  local rc=$?
  printf '\nFAILED (exit %s) at line %s.\n' "$rc" "${BASH_LINENO[0]}" >&2
  if [[ -n "$CURRENT_LOG" && -f "$CURRENT_LOG" ]]; then
    printf -- '--- last 40 lines of %s ---\n' "$CURRENT_LOG" >&2
    tail -40 "$CURRENT_LOG" >&2
  fi
  exit "$rc"
}
trap on_err ERR

# run <logname> <command...> : everything goes to the log, nothing to the screen
run() { local log="$LOGS/$1.log"; shift; CURRENT_LOG="$log"; { echo "\$ $*"; "$@"; } >>"$log" 2>&1; CURRENT_LOG=""; }

# Stamps: a step is done when its stamp holds the same key (hash of its inputs).
key_of() { printf '%s\n' "$@" | shasum -a 256 | cut -c1-16; }
done_step() { [[ -f "$STAMPS/$1" && "$(cat "$STAMPS/$1")" == "$2" ]]; }
mark_step() { mkdir -p "$STAMPS"; printf '%s' "$2" > "$STAMPS/$1"; }

# --------------------------------------------------------------- preflight ---
preflight() {
  [[ "$(uname -s)" == "Darwin" ]] || die "run this on macOS (the Linux trial lives in linux_trial/)"
  [[ "$WORK$OUT$SCRIPT_DIR" != *" "* ]] || die "WORK, OUT and the script folder must not contain spaces (FFmpeg's configure cannot cope)"
  command -v xcrun >/dev/null || die "Xcode command-line tools missing (xcode-select --install)"
  xcodebuild -version >/dev/null 2>&1 || die "xcodebuild unusable: open Xcode once, or 'sudo xcodebuild -license accept'"
  [[ -f "$FLAGS_FILE" ]] || die "missing $FLAGS_FILE"
  [[ -x "$SHIM" ]] || chmod +x "$SHIM"
  command -v "$PYTHON3" >/dev/null || die "$PYTHON3 not found (it comes with Xcode's command-line tools)"
  for t in curl shasum tar make lipo install_name_tool otool plutil; do
    command -v "$t" >/dev/null || xcrun -f "$t" >/dev/null 2>&1 || die "missing tool: $t"
  done
  if [[ "${CLEAN:-0}" == 1 && -d "$WORK" ]]; then say "CLEAN=1: removing $WORK"; chmod -R u+w "$WORK"; rm -rf "$WORK"; fi
  mkdir -p "$LOGS" "$STAMPS" "$DL" "$SRC" "$OUT"
  {
    echo "date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "macOS: $(sw_vers -productVersion) ($(uname -m))"
    xcodebuild -version | tr '\n' ' '; echo
    echo "clang: $(xcrun clang --version | head -1)"
    echo "iPhoneOS SDK: $(xcrun --sdk iphoneos --show-sdk-version)  iPhoneSimulator SDK: $(xcrun --sdk iphonesimulator --show-sdk-version)"
    echo "IOS_MIN=$IOS_MIN SMALL=$SMALL DSYM=$DSYM FFTOOLS=$FFTOOLS SLICES=$SLICES"
  } > "$LOGS/toolchain.txt"
  say "toolchain: $(sed -n 3p "$LOGS/toolchain.txt")"
}

# ------------------------------------------------------------ fetch/extract --
fetch() {  # fetch <url> <file> <sha256 or empty>
  local url="$1" file="$DL/$2" sha="$3"
  if [[ -f "$file" && -n "$sha" && "$(shasum -a 256 "$file" | cut -d' ' -f1)" == "$sha" ]]; then return 0; fi
  if [[ -n "${MIRROR_DIR:-}" && -f "$MIRROR_DIR/$2" ]]; then cp "$MIRROR_DIR/$2" "$file.part"
  else say "download $2"; run fetch curl --fail --location --retry 3 --silent --show-error -o "$file.part" "$url"; fi
  local got; got="$(shasum -a 256 "$file.part" | cut -d' ' -f1)"
  if [[ -z "$sha" ]]; then say "NOTE: $2 has SHA-256 $got — pin it in this script"
  elif [[ "$got" != "$sha" ]]; then
    rm -f "$file.part"
    die "$2: SHA-256 mismatch (got $got, want $sha). If GitHub regenerated its archive, use the copy published in Collaj's source bundle: MIRROR_DIR=<folder> ./build_ffmpeg_ios.sh"
  fi
  mv "$file.part" "$file"
}

extract() {  # extract <tarball> <dir name inside>; sources are never modified
  local tb="$DL/$1" dir="$2" k; k="$(key_of "$(shasum -a 256 "$tb")")"
  done_step "extract-$dir" "$k" && [[ -d "$SRC/$dir" ]] && return 0
  if [[ -d "$SRC/$dir" ]]; then chmod -R u+w "$SRC/$dir"; rm -rf "${SRC:?}/${dir:?}"; fi
  run extract tar -xf "$tb" -C "$SRC"
  [[ -d "$SRC/$dir" ]] || die "unexpected layout in $1"
  chmod -R a-w "$SRC/$dir"      # read-only: proof that the build does not patch sources
  mark_step "extract-$dir" "$k"
}

# FFmpeg's sources as they are built: a copy of the release tarball with
# patches/*.patch applied, read-only — or, with COLLAJ_FFMPEG_PATCHES=0, the
# release tarball itself, read-only too.
ffmpeg_sources() {
  FFSRC="$SRC/ffmpeg-$FFMPEG_VERSION"; PATCHES_KEY=""
  [[ "${COLLAJ_FFMPEG_PATCHES:-1}" == 1 ]] || return 0
  local p list=() k
  for p in "$PATCHES_DIR"/*.patch; do [[ -f "$p" ]] && list+=("$p"); done
  [[ ${#list[@]} -gt 0 ]] || die "COLLAJ_FFMPEG_PATCHES=1 but no patches/*.patch"
  PATCHES_KEY="$(cat "${list[@]}" | shasum -a 256 | cut -c1-16)"
  FFSRC="$SRC/ffmpeg-$FFMPEG_VERSION-collaj"
  k="$(key_of patch "$FFMPEG_SHA256" "$PATCHES_KEY")"
  done_step "patch-ffmpeg" "$k" && [[ -d "$FFSRC" ]] && return 0
  if [[ -d "$FFSRC" ]]; then chmod -R u+w "$FFSRC"; rm -rf "${FFSRC:?}"; fi
  cp -R "$SRC/ffmpeg-$FFMPEG_VERSION" "$FFSRC"; chmod -R u+w "$FFSRC"
  for p in "${list[@]}"; do run patch-ffmpeg patch -p1 -d "$FFSRC" -i "$p"; done
  chmod -R a-w "$FFSRC"
  mark_step "patch-ffmpeg" "$k"
}

# ------------------------------------------------------------- per slice ----
slice_env() {  # sets SDK, TRIPLE, ARCH, FFARCH, CC, CXX, AR, RANLIB, NM, STRIP, PREFIX, BUILD
  local s="$1"
  case "$s" in
    ios-arm64)            SDKNAME=iphoneos;        ARCH=arm64;  FFARCH=aarch64; TRIPLE="arm64-apple-ios${IOS_MIN}";;
    ios-arm64-simulator)  SDKNAME=iphonesimulator; ARCH=arm64;  FFARCH=aarch64; TRIPLE="arm64-apple-ios${IOS_MIN}-simulator";;
    ios-x86_64-simulator) SDKNAME=iphonesimulator; ARCH=x86_64; FFARCH=x86_64;  TRIPLE="x86_64-apple-ios${IOS_MIN}-simulator";;
    *) die "unknown slice $s";;
  esac
  SDK="$(xcrun --sdk "$SDKNAME" --show-sdk-path)"
  CC="$(xcrun --sdk "$SDKNAME" -f clang)"; CXX="$(xcrun --sdk "$SDKNAME" -f clang++)"
  AR="$(xcrun --sdk "$SDKNAME" -f ar)"; RANLIB="$(xcrun --sdk "$SDKNAME" -f ranlib)"
  NM="$(xcrun --sdk "$SDKNAME" -f nm)"; STRIP="$(xcrun --sdk "$SDKNAME" -f strip)"
  PREFIX="$WORK/prefix/$s"; BUILD="$WORK/build/$s"
  # No absolute build path ends up in the binaries (reproducible, no user name).
  PATHMAP="-ffile-prefix-map=$WORK=/collaj-ffmpeg-build"
  mkdir -p "$PREFIX/lib/pkgconfig" "$PREFIX/include" "$BUILD"
}

build_zimg() {  # every .cpp under src/zimg except x86/ (and arm/ unless arm64)
  local s="$1" z="$SRC/zimg-release-$ZIMG_VERSION" k
  k="$(key_of zimg "$ZIMG_SHA256" "$s" "$IOS_MIN" "$SCRIPT_REV")"
  done_step "zimg-$s" "$k" && return 0
  say "  zimg $ZIMG_VERSION"
  local o="$BUILD/zimg"; rm -rf "$o"; mkdir -p "$o"
  local defs=() excl=(! -path '*/x86/*')
  if [[ "$ARCH" == arm64 ]]; then defs=(-DZIMG_ARM); else excl+=(! -path '*/arm/*'); fi
  local f p pids=()
  while IFS= read -r f; do
    run "zimg-$s" "$CXX" -target "$TRIPLE" -isysroot "$SDK" -std=c++14 -O2 -fPIC -DNDEBUG ${defs[@]+"${defs[@]}"} $PATHMAP \
        -I"$z/src/zimg" -c "$z/$f" -o "$o/$(echo "$f" | tr '/' '_').o" &
    pids+=($!)
    if (( ${#pids[@]} >= JOBS )); then
      for p in "${pids[@]}"; do wait "$p" || die "zimg: a compile failed, see $LOGS/zimg-$s.log"; done; pids=()
    fi
  done < <(cd "$z" && find src/zimg -name '*.cpp' "${excl[@]}" | sort)
  for p in ${pids[@]+"${pids[@]}"}; do wait "$p" || die "zimg: a compile failed, see $LOGS/zimg-$s.log"; done
  run "zimg-$s" "$AR" rcs "$PREFIX/lib/libzimg.a" "$o"/*.o
  run "zimg-$s" "$RANLIB" "$PREFIX/lib/libzimg.a"
  cp "$z/src/zimg/api/zimg.h" "$z/src/zimg/api/zimg++.hpp" "$PREFIX/include/"
  cat > "$PREFIX/lib/pkgconfig/zimg.pc" <<EOF
prefix=$PREFIX
libdir=\${prefix}/lib
includedir=\${prefix}/include
Name: zimg
Description: Scaling, colorspace conversion, and dithering library
Version: $ZIMG_VERSION
Libs: -L\${libdir} -lzimg
Libs.private: -lc++
Cflags: -I\${includedir}
EOF
  mark_step "zimg-$s" "$k"
}

build_openh264() {  # upstream Makefile, out of tree, static only
  local s="$1" k asm=Yes
  k="$(key_of openh264 "$OPENH264_SHA256" "$s" "$IOS_MIN" "$SCRIPT_REV")"
  done_step "openh264-$s" "$k" && return 0
  say "  OpenH264 $OPENH264_VERSION"
  [[ "$ARCH" == x86_64 ]] && asm=No        # x86 asm needs nasm: not worth it for a simulator slice
  local o="$BUILD/openh264"; rm -rf "$o"; mkdir -p "$o"
  ( cd "$o" && run "openh264-$s" make -f "$SRC/openh264-$OPENH264_VERSION/Makefile" -j"$JOBS" \
      OS=darwin ARCH="$ARCH" USE_ASM="$asm" PREFIX="$PREFIX" \
      CC="$CC -target $TRIPLE -isysroot $SDK $PATHMAP" CXX="$CXX -target $TRIPLE -isysroot $SDK $PATHMAP" \
      AR="$AR" STATIC_LDFLAGS="-lc++" install-static )
  mark_step "openh264-$s" "$k"
}

python_tools() {  # meson + ninja for dav1d: a venv in $WORK, hash-pinned wheels only
  PYTOOLS="$WORK/pytools"
  local k; k="$(key_of pytools "$MESON_VERSION" "$MESON_WHL_SHA256" "$NINJA_VERSION" "$NINJA_WHL_SHA256_MAC" "$("$PYTHON3" -V 2>&1)")"
  if ! done_step pytools "$k" || [[ ! -x "$PYTOOLS/bin/meson" || ! -x "$PYTOOLS/bin/ninja" ]]; then
    say "meson $MESON_VERSION + ninja $NINJA_VERSION (pip, pinned) into $PYTOOLS"
    rm -rf "$PYTOOLS"
    printf '%s\n' "meson==$MESON_VERSION --hash=sha256:$MESON_WHL_SHA256" \
      "ninja==$NINJA_VERSION --hash=sha256:$NINJA_WHL_SHA256_MAC --hash=sha256:$NINJA_WHL_SHA256_LINUX_ARM64" \
      > "$WORK/pytools-requirements.txt"
    local pipargs=(install --disable-pip-version-check --no-input --only-binary=:all: --require-hashes -r "$WORK/pytools-requirements.txt")
    if run pytools "$PYTHON3" -m venv "$PYTOOLS" && [[ -x "$PYTOOLS/bin/pip" ]]; then
      run pytools "$PYTOOLS/bin/python" -m pip "${pipargs[@]}"
    else   # a python without ensurepip: empty venv, filled by the outer pip (pip >= 22.3)
      rm -rf "$PYTOOLS"
      run pytools "$PYTHON3" -m venv --without-pip "$PYTOOLS"
      run pytools "$PYTHON3" -m pip --python "$PYTOOLS/bin/python" "${pipargs[@]}"
    fi
    mark_step pytools "$k"
  fi
  MESON_V="$("$PYTOOLS/bin/meson" --version)"; NINJA_V="$("$PYTOOLS/bin/ninja" --version)"
  echo "meson $MESON_V, ninja $NINJA_V (PyPI wheels, SHA-256 pinned) under $("$PYTOOLS/bin/python" -V 2>&1)" >> "$LOGS/toolchain.txt"
  say "build tools: meson $MESON_V, ninja $NINJA_V"
}

build_dav1d() {  # meson cross build, static, one cross file per slice
  local s="$1" k asm=true fam=aarch64 cpu=arm64 sub=ios
  k="$(key_of dav1d "$DAV1D_SHA256" "$s" "$IOS_MIN" "$SCRIPT_REV" "$MESON_VERSION" "$NINJA_VERSION")"
  done_step "dav1d-$s" "$k" && return 0
  say "  dav1d $DAV1D_VERSION"
  if [[ "$ARCH" == x86_64 ]]; then fam=x86_64; cpu=x86_64; asm=false; fi   # x86 asm needs nasm: off for that simulator slice
  if [[ "$s" == *simulator ]]; then sub=ios-simulator; fi
  local o="$BUILD/dav1d" cross="$BUILD/dav1d-cross.ini"; rm -rf "$o"
  # The -target triple carries the minimum version (iOS $IOS_MIN) for compiling and linking.
  cat > "$cross" <<EOF
# meson cross file for dav1d, slice $s (generated by build_ffmpeg_ios.sh)
[binaries]
c = ['$CC', '-arch', '$ARCH', '-target', '$TRIPLE', '-isysroot', '$SDK']
ar = '$AR'
strip = '$STRIP'

[built-in options]
c_args = ['$PATHMAP']

[properties]
needs_exe_wrapper = true

[host_machine]
system = 'darwin'
subsystem = '$sub'
kernel = 'xnu'
cpu_family = '$fam'
cpu = '$cpu'
endian = 'little'
EOF
  PATH="$PYTOOLS/bin:$PATH" run "dav1d-$s" "$PYTOOLS/bin/meson" setup "$o" "$SRC/dav1d-$DAV1D_VERSION" \
      --cross-file "$cross" --prefix "$PREFIX" --libdir lib \
      --buildtype release --default-library static \
      -Denable_asm="$asm" -Denable_tools=false -Denable_tests=false -Denable_docs=false
  PATH="$PYTOOLS/bin:$PATH" run "dav1d-$s" "$PYTOOLS/bin/ninja" -C "$o" -j "$JOBS" install
  [[ -f "$PREFIX/lib/libdav1d.a" && -f "$PREFIX/lib/pkgconfig/dav1d.pc" ]] || die "dav1d: no libdav1d.a / dav1d.pc in $PREFIX/lib"
  mark_step "dav1d-$s" "$k"
}

read_flags() {  # configure_flags.txt -> FLAGS array ([apple] kept, [linux] dropped)
  FLAGS=()
  local line
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%%#*}"; line="$(echo "$line" | xargs)"; [[ -z "$line" ]] && continue
    case "$line" in
      "[linux] "*) continue ;;
      "[apple] "*) line="${line#\[apple\] }" ;;
    esac
    FLAGS+=("$line")
  done < "$FLAGS_FILE"
}

build_ffmpeg() {
  local s="$1" k extra=()
  read_flags
  k="$(key_of ffmpeg "$FFMPEG_SHA256" "$s" "$IOS_MIN" "$SMALL" "$DSYM" "$SCRIPT_REV" "$(shasum -a 256 "$FLAGS_FILE")" \
        "$(cat "$STAMPS/zimg-$s" "$STAMPS/openh264-$s" "$STAMPS/dav1d-$s")" ${PATCHES_KEY:+"$PATCHES_KEY"})"
  done_step "ffmpeg-$s" "$k" && return 0
  say "  FFmpeg $FFMPEG_VERSION (${#FLAGS[@]} flags from configure_flags.txt)"
  [[ "$ARCH" == x86_64 ]] && extra+=(--disable-x86asm)   # no nasm needed; simulator only
  [[ "$SMALL" == 1 ]] && extra+=(--enable-small)
  local o="$BUILD/ffmpeg"; rm -rf "$o" "$PREFIX/ffmpeg"; mkdir -p "$o"
  # From $WORK, not from the script's folder: configure records its own path in
  # the binaries, and the script's folder has the user name in it.
  cp "$SHIM" "$WORK/pkg-config-shim.sh"; chmod +x "$WORK/pkg-config-shim.sh"
  ( cd "$o" && export PKG_CONFIG_LIBDIR="$PREFIX/lib/pkgconfig" && run "ffmpeg-configure-$s" \
      "$FFSRC/configure" \
      --prefix="$PREFIX/ffmpeg" \
      --enable-cross-compile --target-os=darwin --arch="$FFARCH" \
      --cc="$CC" --cxx="$CXX" --ar="$AR" --ranlib="$RANLIB" --nm="$NM" --strip="$STRIP" \
      --sysroot="$SDK" \
      --extra-cflags="-target $TRIPLE $PATHMAP" --extra-cxxflags="-target $TRIPLE $PATHMAP" \
      --extra-ldflags="-target $TRIPLE -Wl,-headerpad_max_install_names" \
      --install-name-dir='@rpath' --disable-stripping \
      --pkg-config="$WORK/pkg-config-shim.sh" --pkg-config-flags=--static \
      "${FLAGS[@]}" ${extra[@]+"${extra[@]}"} )
  grep -q "License: LGPL version 2.1 or later" "$LOGS/ffmpeg-configure-$s.log" \
    || die "configure did not end with 'License: LGPL version 2.1 or later' (see $LOGS/ffmpeg-configure-$s.log)"
  ( cd "$o" && run "ffmpeg-make-$s" make -j"$JOBS" && run "ffmpeg-make-$s" make install )
  mark_step "ffmpeg-$s" "$k"
}

plist() {  # plist <file> <executable> <version> <platform>
  cat > "$1" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key><string>en</string>
  <key>CFBundleExecutable</key><string>$2</string>
  <key>CFBundleIdentifier</key><string>$BUNDLE_ID_PREFIX.$2</string>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>CFBundleName</key><string>$2</string>
  <key>CFBundlePackageType</key><string>FMWK</string>
  <key>CFBundleShortVersionString</key><string>$3</string>
  <key>CFBundleVersion</key><string>$3</string>
  <key>CFBundleSupportedPlatforms</key><array><string>$4</string></array>
  <key>MinimumOSVersion</key><string>$IOS_MIN</string>
</dict>
</plist>
EOF
  plutil -lint "$1" >/dev/null
}

make_frameworks() {  # dylibs -> <lib>.framework with @rpath/<lib>.framework/<lib> ids
  local s="$1" platform=iPhoneOS lib dylib ver fw dep base k
  [[ "$s" == *simulator ]] && platform=iPhoneSimulator
  k="$(key_of fw "$(cat "$STAMPS/ffmpeg-$s")" "$BUNDLE_ID_PREFIX" "$DSYM")"
  done_step "frameworks-$s" "$k" && return 0
  say "  frameworks"
  rm -rf "$WORK/frameworks/$s" "$WORK/dsyms/$s"; mkdir -p "$WORK/frameworks/$s" "$WORK/dsyms/$s"
  for lib in "${LIBS[@]}"; do
    dylib="$(cd "$PREFIX/ffmpeg/lib" && ls "$lib".*.*.*.dylib | head -1)"      # libavcodec.62.28.102.dylib
    ver="${dylib#"$lib".}"; ver="${ver%.dylib}"
    fw="$WORK/frameworks/$s/$lib.framework"; mkdir -p "$fw/Headers"
    cp "$PREFIX/ffmpeg/lib/$dylib" "$fw/$lib"
    install_name_tool -id "@rpath/$lib.framework/$lib" "$fw/$lib"
    for dep in $(otool -L "$fw/$lib" | awk 'NR>1 {print $1}' | grep '^@rpath/lib' || true); do
      base="$(basename "$dep")"; base="${base%%.*}"                               # libavutil
      install_name_tool -change "$dep" "@rpath/$base.framework/$base" "$fw/$lib"
    done
    cp -R "$PREFIX/ffmpeg/include/$lib/." "$fw/Headers/"
    plist "$fw/Info.plist" "$lib" "$ver" "$platform"
    if [[ "$DSYM" == 1 ]]; then run "dsym-$s" xcrun dsymutil "$fw/$lib" -o "$WORK/dsyms/$s/$lib.framework.dSYM"; fi
    run "strip-$s" "$STRIP" -x -S "$fw/$lib"
    run "sign-$s" codesign --force --sign - "$fw/$lib"      # ad hoc; Xcode re-signs when embedding
  done
  mark_step "frameworks-$s" "$k"
}

build_fftools() {  # optional: fftools.framework (see the plan, section 5)
  local s="$1" next="$SRC/ffmpeg-kit-next-$FFKIT_NEXT_VERSION/apple/src" k
  k="$(key_of fftools "$(cat "$STAMPS/frameworks-$s")" "$FFKIT_NEXT_SHA256" \
        "$(cat "$SCRIPT_DIR"/bridge/native/*.c "$SCRIPT_DIR"/bridge/native/*.h | shasum -a 256)")"
  done_step "fftools-$s" "$k" && return 0
  say "  fftools.framework"
  local o="$BUILD/fftools" fw="$WORK/frameworks/$s/fftools.framework" platform=iPhoneOS
  [[ "$s" == *simulator ]] && platform=iPhoneSimulator
  rm -rf "$o" "$fw"; mkdir -p "$o" "$fw/Headers" "$fw/Modules"
  # FFmpeg's own preprocessor flags for this slice, minus HAVE_AV_CONFIG_H (fftools
  # must see the public headers only, as FFmpegKit compiles them).
  local cppflags; cppflags="$(sed -n 's/^CPPFLAGS=//p' "$BUILD/ffmpeg/ffbuild/config.mak")"
  local f srcs=()
  for f in "$next"/fftools/*.c "$next"/fftools/graph/*.c "$next"/fftools/resources/*.c \
           "$next"/fftools/textformat/*.c "$next/ffmpeg_context.c" "$SCRIPT_DIR"/bridge/native/*.c; do
    [[ "$f" == */ffprobe.c ]] && continue       # media information comes from collaj_probe_json()
    srcs+=("$f")
  done
  for f in "${srcs[@]}"; do
    run "fftools-$s" "$CC" -target "$TRIPLE" -isysroot "$SDK" -std=gnu17 -O2 -fPIC $cppflags $PATHMAP \
        -I"$next" -I"$next/fftools" -I"$BUILD/ffmpeg" -I"$FFSRC" -I"$SCRIPT_DIR/bridge/native" \
        -c "$f" -o "$o/$(basename "$f" .c).o"
  done
  run "fftools-$s" "$CC" -target "$TRIPLE" -isysroot "$SDK" -dynamiclib -o "$fw/fftools" "$o"/*.o \
      -install_name @rpath/fftools.framework/fftools -Wl,-headerpad_max_install_names \
      -F"$WORK/frameworks/$s" -framework libavfilter -framework libavformat -framework libavcodec \
      -framework libswresample -framework libswscale -framework libavutil
  cp "$SCRIPT_DIR/bridge/native/collaj_ffmpeg.h" "$fw/Headers/"
  printf 'framework module fftools {\n  umbrella header "collaj_ffmpeg.h"\n  export *\n}\n' > "$fw/Modules/module.modulemap"
  plist "$fw/Info.plist" fftools "$FFKIT_NEXT_VERSION" "$platform"
  if [[ "$DSYM" == 1 ]]; then run "dsym-$s" xcrun dsymutil "$fw/fftools" -o "$WORK/dsyms/$s/fftools.framework.dSYM"; fi
  run "strip-$s" "$STRIP" -x -S "$fw/fftools"
  run "sign-$s" codesign --force --sign - "$fw/fftools"
  mark_step "fftools-$s" "$k"
}

# ------------------------------------------------ simulator fat + xcframework
xcframeworks() {
  local names=("${LIBS[@]}") lib args
  [[ "$FFTOOLS" == 1 ]] && names+=(fftools)
  local sims=() s
  for s in $SLICES; do if [[ "$s" == *simulator ]]; then sims+=("$s"); fi; done
  mkdir -p "$OUT/xcframeworks"
  for lib in "${names[@]}"; do
    args=()
    if [[ " $SLICES " == *" ios-arm64 "* ]]; then
      args+=(-framework "$WORK/frameworks/ios-arm64/$lib.framework")
      if [[ "$DSYM" == 1 ]]; then args+=(-debug-symbols "$WORK/dsyms/ios-arm64/$lib.framework.dSYM"); fi
    fi
    if (( ${#sims[@]} > 0 )); then
      local fat="$WORK/frameworks/ios-simulator/$lib.framework" fatd="$WORK/dsyms/ios-simulator/$lib.framework.dSYM"
      rm -rf "$fat" "$fatd"; mkdir -p "$(dirname "$fat")" "$(dirname "$fatd")"
      cp -R "$WORK/frameworks/${sims[0]}/$lib.framework" "$fat"
      local bins=() dbins=()
      for s in "${sims[@]}"; do
        bins+=("$WORK/frameworks/$s/$lib.framework/$lib")
        dbins+=("$WORK/dsyms/$s/$lib.framework.dSYM/Contents/Resources/DWARF/$lib")
      done
      run xcframework lipo -create "${bins[@]}" -output "$fat/$lib"
      args+=(-framework "$fat")
      if [[ "$DSYM" == 1 ]]; then
        cp -R "$WORK/dsyms/${sims[0]}/$lib.framework.dSYM" "$fatd"
        run xcframework lipo -create "${dbins[@]}" -output "$fatd/Contents/Resources/DWARF/$lib"
        args+=(-debug-symbols "$fatd")
      fi
    fi
    rm -rf "$OUT/xcframeworks/$lib.xcframework"
    run xcframework xcodebuild -create-xcframework "${args[@]}" -output "$OUT/xcframeworks/$lib.xcframework"
  done
}

# ------------------------------------------------------------------ checks ---
verify() {
  local s=ios-arm64 lib bad=0
  [[ " $SLICES " == *" $s "* ]] || return 0
  say "verify (iPhone slice)"
  for lib in "${LIBS[@]}"; do
    local b="$WORK/frameworks/$s/$lib.framework/$lib"
    # Allowed dependencies: our frameworks, libSystem/libz/libc++/libiconv? (no), Apple frameworks.
    otool -L "$b" | awk 'NR>1 {print $1}' | while read -r d; do
      case "$d" in
        @rpath/lib*.framework/lib*|/usr/lib/libSystem.B.dylib|/usr/lib/libz.1.dylib|/usr/lib/libc++.1.dylib) ;;
        /System/Library/Frameworks/*) ;;
        *) echo "UNEXPECTED DEPENDENCY in $lib: $d"; exit 1 ;;
      esac
    done || bad=1
    otool -l "$b" | grep -A4 LC_BUILD_VERSION | grep -q "minos $IOS_MIN" || { echo "$lib: minos != $IOS_MIN"; bad=1; }
  done
  strings "$WORK/frameworks/$s/libavutil.framework/libavutil" | grep -q -- "--disable-everything" \
    || { echo "configure line not found in libavutil"; bad=1; }
  if strings "$WORK/frameworks/$s/libavutil.framework/libavutil" | grep -q -- "--enable-gpl\|--enable-nonfree\|--enable-version3"; then
    echo "GPL/nonfree/version3 flag found in the configure line"; bad=1
  fi
  (( bad == 0 )) || die "verification failed"
}

# ----------------------------------------------------------------- notices --
# NOTICES_ffmpeg.txt IS the app's licenses/ffmpeg_libraries.txt: copy it over
# after each build (Flutter's NOTICES format — package names one per line, a
# blank line, the text, entries separated by a line of exactly 80 hyphens).
# Licence texts come from the source trees built, so they match the versions
# shipped. A line of 80 hyphens inside a text would split its entry: 79 kept.
SEP80="--------------------------------------------------------------------------------"
notice_entry() {  # notice_entry <file> <names, "\n"-separated> <text files...>
  local out="$1" heads="$2" f; shift 2
  if [[ -s "$out" ]]; then printf '%s\n' "$SEP80" >> "$out"; fi
  {
    printf '%b\n\n' "$heads"
    for f in "$@"; do
      sed "s/^${SEP80}\$/${SEP80#-}/" "$f"
      if [[ -n "$(tail -c 1 "$f")" ]]; then echo; fi   # a text without its final newline (OpenH264's)
    done
  } >> "$out"
}
notices() {
  local d="$1" n="$1/NOTICES_ffmpeg.txt" f="$SRC/ffmpeg-$FFMPEG_VERSION" t="$1/.notices"
  mkdir -p "$d/licenses" "$t"; rm -f "$n"
  cat > "$t/ffmpeg" <<EOF
FFmpeg $FFMPEG_VERSION (https://ffmpeg.org/), built for Collaj by
tool/ffmpeg/build_ffmpeg_ios.sh and shipped as the libavutil, libavcodec,
libavformat, libavfilter, libswscale and libswresample frameworks, with
fftools.framework (FFmpeg's command-line tool, as a library).

Copyright (c) 2000-2026 the FFmpeg developers

The libraries were configured without --enable-gpl, --enable-nonfree and
--enable-version3: they are distributed under the GNU Lesser General Public
License, version 2.1 or (at your option) any later version. zimg, OpenH264
and dav1d are linked into them (entries below). fftools.framework holds
FFmpeg's fftools as modified by FFmpegKitNext, distributed under the GNU
Lesser General Public License, version 3 or (at your option) any later
version, which incorporates the GNU General Public License version 3.
FFmpeg's own description of its licensing (LICENSE.md) follows; the full texts
of the LGPL 3.0, the GPL 3.0 and the LGPL 2.1 are in the next entries.

This software is based in part on the work of the Independent JPEG Group.

Upstream source: https://ffmpeg.org/releases/ffmpeg-$FFMPEG_VERSION.tar.xz
(https://git.ffmpeg.org/ffmpeg.git, tag n$FFMPEG_VERSION)

EOF
  cat > "$t/ffkit" <<EOF
fftools.framework: the fftools of FFmpeg $FFMPEG_VERSION (ffmpeg.c, ffmpeg_*.c,
cmdutils.c, opt_common.c and their helpers) as adapted to run as a library by
FFmpegKitNext v$FFKIT_NEXT_VERSION (https://github.com/arthenica/ffmpeg-kit-next),
with Collaj's own C glue (collaj_ffmpeg.c, MIT).

Copyright (c) 2000-2003 Fabrice Bellard
Copyright (c) 2018-2022, 2026 Taner Sener
Copyright (c) 2023-2024 ARTHENICA LTD

Distributed under the GNU Lesser General Public License, version 3 or (at
your option) any later version. Its text and that of the GNU General Public
License version 3 are in the next entries.
EOF
  printf 'zimg %s (https://github.com/sekrit-twc/zimg), linked into libavfilter.\n\n' "$ZIMG_VERSION" > "$t/zimg"
  printf 'OpenH264 %s (https://github.com/cisco/openh264), linked into libavcodec.\n\n' "$OPENH264_VERSION" > "$t/openh264"
  printf 'dav1d %s (https://code.videolan.org/videolan/dav1d), linked into libavcodec.\n\n' "$DAV1D_VERSION" > "$t/dav1d"
  local ffk="FFmpeg"
  if [[ "$FFTOOLS" == 1 ]]; then ffk="FFmpeg\nFFmpegKitNext"; fi

  notice_entry "$n" FFmpeg "$t/ffmpeg" "$f/LICENSE.md"
  if [[ "$FFTOOLS" == 1 ]]; then notice_entry "$n" FFmpegKitNext "$t/ffkit"; fi
  notice_entry "$n" "$ffk" "$f/COPYING.LGPLv3"
  notice_entry "$n" "$ffk" "$f/COPYING.GPLv3"
  notice_entry "$n" FFmpeg "$f/COPYING.LGPLv2.1"
  notice_entry "$n" zimg "$t/zimg" "$SRC/zimg-release-$ZIMG_VERSION/COPYING"
  notice_entry "$n" OpenH264 "$t/openh264" "$SRC/openh264-$OPENH264_VERSION/LICENSE"
  notice_entry "$n" dav1d "$t/dav1d" "$SRC/dav1d-$DAV1D_VERSION/COPYING"
  rm -rf "$t"

  cp "$f/COPYING.LGPLv2.1" "$f/COPYING.LGPLv3" "$f/COPYING.GPLv3" "$f/LICENSE.md" "$d/licenses/"
  cp "$SRC/zimg-release-$ZIMG_VERSION/COPYING" "$d/licenses/zimg-COPYING"
  cp "$SRC/openh264-$OPENH264_VERSION/LICENSE" "$d/licenses/openh264-LICENSE"
  cp "$SRC/dav1d-$DAV1D_VERSION/COPYING" "$d/licenses/dav1d-COPYING"
  if [[ "$FFTOOLS" == 1 ]]; then cp "$SRC/ffmpeg-kit-next-$FFKIT_NEXT_VERSION/LICENSE" "$d/licenses/ffmpeg-kit-next-LICENSE"; fi
}

# ---------------------------------------------------------- source bundle ---
source_bundle() {
  say "source bundle"
  local d="$OUT/SOURCES/collaj-ffmpeg-$FFMPEG_VERSION-sources"
  rm -rf "$OUT/SOURCES"; mkdir -p "$d/tarballs" "$d/scripts/tools"
  cp "$DL/ffmpeg-$FFMPEG_VERSION.tar.xz" "$DL/ffmpeg-$FFMPEG_VERSION.tar.xz.asc" "$DL/zimg-release-$ZIMG_VERSION.tar.gz" "$DL/openh264-$OPENH264_VERSION.tar.gz" \
     "$DL/dav1d-$DAV1D_VERSION.tar.xz" "$DL/dav1d-$DAV1D_VERSION.tar.xz.asc" "$d/tarballs/"
  [[ "$FFTOOLS" == 1 ]] && cp "$DL/ffmpeg-kit-next-$FFKIT_NEXT_VERSION.tar.gz" "$d/tarballs/"
  cp "$SCRIPT_DIR/build_ffmpeg_ios.sh" "$SCRIPT_DIR/configure_flags.txt" "$d/scripts/"
  cp "$SHIM" "$d/scripts/tools/"
  [[ -d "$SCRIPT_DIR/bridge/native" ]] && mkdir -p "$d/scripts/bridge" && cp -R "$SCRIPT_DIR/bridge/native" "$d/scripts/bridge/"
  cp "$LOGS/toolchain.txt" "$d/"
  # The exact configure invocation of each slice, as FFmpeg recorded it.
  local s
  for s in $SLICES; do
    { echo "# $s"; sed -n 's/^#define FFMPEG_CONFIGURATION "\(.*\)"$/\1/p' "$WORK/build/$s/ffmpeg/config.h"; echo; } >> "$d/configure_lines.txt"
  done
  if [[ -n "$PATCHES_KEY" ]]; then
    mkdir -p "$d/scripts/patches"; cp "$PATCHES_DIR"/*.patch "$PATCHES_DIR/README.md" "$d/scripts/patches/"
    { printf '# FFmpeg %s is built from its release tarball listed in SOURCES.md with the patches below applied\n# (patch -p1); zimg %s, OpenH264 %s and dav1d %s from their unmodified release tarballs.\n' \
        "$FFMPEG_VERSION" "$ZIMG_VERSION" "$OPENH264_VERSION" "$DAV1D_VERSION"; cat "$PATCHES_DIR"/*.patch; } > "$d/changes.diff"
  else
  printf '# No changes: FFmpeg %s, zimg %s, OpenH264 %s and dav1d %s are built from the\n# unmodified release tarballs listed in SOURCES.md (the build makes them read-only).\n' \
    "$FFMPEG_VERSION" "$ZIMG_VERSION" "$OPENH264_VERSION" "$DAV1D_VERSION" > "$d/changes.diff"
  fi
  notices "$d"
  ( cd "$d/tarballs" && shasum -a 256 ./* > ../SHA256SUMS )
  if [[ -f "$SCRIPT_DIR/SOURCES.md" ]]; then
    cp "$SCRIPT_DIR/SOURCES.md" "$d/SOURCES.md"
    # What was done to FFmpeg, said where the notice says it (LGPL §2a: modified files carry a notice).
    local state changes
    if [[ -n "$PATCHES_KEY" ]]; then
      state="$FFMPEG_VERSION, release tarball with Collaj's patches applied (\`changes.diff\`, \`scripts/patches/\`)"
      changes="\`changes.diff\`: the patches applied to FFmpeg's release tarball (\`patch -p1\`, by the build script), each dated and explained in \`scripts/patches/README.md\`; zimg, OpenH264 and dav1d are unmodified."
    else
      state="$FFMPEG_VERSION, unmodified release tarball"
      changes="\`changes.diff\`: **empty** — no patch is applied to FFmpeg, zimg, OpenH264 or dav1d."
    fi
    STATE="$state" CHANGES="$changes" "$PYTHON3" -c 'import os, sys; p = sys.argv[1]; t = open(p, encoding="utf-8").read(); t = t.replace("{{FFMPEG_STATE}}", os.environ["STATE"]).replace("{{FFMPEG_CHANGES}}", os.environ["CHANGES"]); open(p, "w", encoding="utf-8").write(t)' "$d/SOURCES.md"
  fi
  ( cd "$OUT/SOURCES" && tar -czf "collaj-ffmpeg-$FFMPEG_VERSION-sources.tar.gz" "collaj-ffmpeg-$FFMPEG_VERSION-sources" \
      && shasum -a 256 "collaj-ffmpeg-$FFMPEG_VERSION-sources.tar.gz" > "collaj-ffmpeg-$FFMPEG_VERSION-sources.tar.gz.sha256" )
}

report() {
  echo
  echo "=== xcframeworks ($OUT/xcframeworks) ==="
  local lib total=0 sz
  for x in "$OUT"/xcframeworks/*.xcframework; do
    printf '  %-28s %8s\n' "$(basename "$x")" "$(du -sh "$x" | cut -f1)"
  done
  if [[ " $SLICES " == *" ios-arm64 "* ]]; then
    echo "=== iPhone (arm64) binary sizes, what the app ships ==="
    for f in "$WORK"/frameworks/ios-arm64/*.framework; do
      lib="$(basename "$f" .framework)"; sz=$(stat -f %z "$f/$lib"); total=$((total + sz))
      printf '  %-16s %10s bytes\n' "$lib" "$sz"
    done
    printf '  %-16s %10s bytes (%s MB)\n' TOTAL "$total" "$(echo "scale=1; $total/1048576" | bc)"
  fi
  echo "=== licence notices: copy over the_collage_app/licenses/ffmpeg_libraries.txt ==="
  echo "  $OUT/SOURCES/collaj-ffmpeg-$FFMPEG_VERSION-sources/NOTICES_ffmpeg.txt"
  echo "=== sources to publish ==="
  ls -1 "$OUT"/SOURCES/*.tar.gz* | sed 's/^/  /'
  say "done in $(( $(date +%s) - T0 )) s — logs in $LOGS"
}

# -------------------------------------------------------------------- main ---
main() {
  preflight
  fetch "$FFMPEG_URL"   "ffmpeg-$FFMPEG_VERSION.tar.xz"         "$FFMPEG_SHA256"
  fetch "$FFMPEG_URL.asc" "ffmpeg-$FFMPEG_VERSION.tar.xz.asc"   "$FFMPEG_ASC_SHA256"
  fetch "$ZIMG_URL"     "zimg-release-$ZIMG_VERSION.tar.gz"     "$ZIMG_SHA256"
  fetch "$OPENH264_URL" "openh264-$OPENH264_VERSION.tar.gz"     "$OPENH264_SHA256"
  fetch "$DAV1D_URL"    "dav1d-$DAV1D_VERSION.tar.xz"           "$DAV1D_SHA256"
  fetch "$DAV1D_URL.asc" "dav1d-$DAV1D_VERSION.tar.xz.asc"      "$DAV1D_ASC_SHA256"
  extract "ffmpeg-$FFMPEG_VERSION.tar.xz"     "ffmpeg-$FFMPEG_VERSION"
  ffmpeg_sources
  extract "zimg-release-$ZIMG_VERSION.tar.gz" "zimg-release-$ZIMG_VERSION"
  extract "openh264-$OPENH264_VERSION.tar.gz" "openh264-$OPENH264_VERSION"
  extract "dav1d-$DAV1D_VERSION.tar.xz"       "dav1d-$DAV1D_VERSION"
  python_tools
  if [[ "$FFTOOLS" == 1 ]]; then
    [[ -f "$SCRIPT_DIR/bridge/native/collaj_ffmpeg.c" ]] || die "FFTOOLS=1 needs bridge/native/collaj_ffmpeg.c"
    fetch "$FFKIT_NEXT_URL" "ffmpeg-kit-next-$FFKIT_NEXT_VERSION.tar.gz" "$FFKIT_NEXT_SHA256"
    extract "ffmpeg-kit-next-$FFKIT_NEXT_VERSION.tar.gz" "ffmpeg-kit-next-$FFKIT_NEXT_VERSION"
  fi
  for s in $SLICES; do
    say "slice $s"
    slice_env "$s"
    build_zimg "$s"
    build_openh264 "$s"
    build_dav1d "$s"
    build_ffmpeg "$s"
    make_frameworks "$s"
    if [[ "$FFTOOLS" == 1 ]]; then build_fftools "$s"; fi
  done
  verify
  say "xcframeworks"
  xcframeworks
  source_bundle
  report
}

# Sourcing the file (tests) defines the functions without building anything.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then main "$@"; fi
