# Collaj for iOS — corresponding source of the FFmpeg libraries

This software uses code of [FFmpeg](https://ffmpeg.org) licensed under the
[LGPLv2.1](https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html) and its
source can be downloaded here.

| | |
|---|---|
| App | Collaj 2.0.0 (build 33), iOS, App Store |
| FFmpeg | 8.1.2, release tarball with Collaj's patches applied (`changes.diff`, `scripts/patches/`) |
| Built on | 2026-11-10, see `toolchain.txt` (macOS, Xcode, clang and SDK versions) |
| Bundle | `collaj-ffmpeg-8.1.2-sources.tar.gz` — its SHA-256 is on the download page (a file cannot carry its own); the archives' are in `SHA256SUMS` |

## 1. What the app contains

Seven dynamic frameworks in `Collaj.app/Frameworks/`, each a separate Mach-O
loaded at run time through `@rpath` (nothing below is linked statically into
the app's executable):

| Framework | Version | Contents | Licence |
|---|---|---|---|
| `libavutil.framework` | 60.26.102 | FFmpeg libavutil | LGPL-2.1-or-later |
| `libswresample.framework` | 6.3.102 | FFmpeg libswresample | LGPL-2.1-or-later |
| `libswscale.framework` | 9.5.102 | FFmpeg libswscale | LGPL-2.1-or-later |
| `libavcodec.framework` | 62.28.102 | FFmpeg libavcodec + OpenH264 2.6.0 (static) + dav1d 1.5.4 (static, AV1 decoding) | LGPL-2.1-or-later; OpenH264 and dav1d BSD-2-Clause |
| `libavformat.framework` | 62.12.102 | FFmpeg libavformat | LGPL-2.1-or-later |
| `libavfilter.framework` | 11.14.102 | FFmpeg libavfilter + zimg 3.0.6 (static) | LGPL-2.1-or-later; zimg WTFPL |
| `fftools.framework` | 8.1.1 | FFmpeg's `ffmpeg` tool as a library (FFmpegKitNext v8.1.1 adaptation of FFmpeg 8.1.2 `fftools/`) + Collaj's glue `collaj_ffmpeg.c` | LGPL-3.0-or-later (glue: MIT) |

FFmpeg was configured **without** `--enable-gpl`, `--enable-nonfree` and
`--enable-version3` (configure's own verdict, recorded in the build log:
"License: LGPL version 2.1 or later"). The exact configure invocation of each
slice is in `configure_lines.txt`; it is also embedded in `libavutil`
(`strings libavutil | grep -- --disable-everything`).

## 2. Sources

All of them are the upstream release archives, byte for byte (see `SHA256SUMS`;
the build script refuses any other file and makes the extracted trees read-only):

| File | Upstream | SHA-256 | Licence |
|---|---|---|---|
| `tarballs/ffmpeg-8.1.2.tar.xz` | https://ffmpeg.org/releases/ffmpeg-8.1.2.tar.xz (signature: `.asc` next to it) | `464beb5e7bf0c311e68b45ae2f04e9cc2af88851abb4082231742a74d97b524c` | LGPL-2.1-or-later (as configured) |
| `tarballs/zimg-release-3.0.6.tar.gz` | https://github.com/sekrit-twc/zimg/archive/refs/tags/release-3.0.6.tar.gz | `be89390f13a5c9b2388ce0f44a5e89364a20c1c57ce46d382b1fcc3967057577` | WTFPL |
| `tarballs/openh264-2.6.0.tar.gz` | https://github.com/cisco/openh264/archive/refs/tags/v2.6.0.tar.gz | `558544ad358283a7ab2930d69a9ceddf913f4a51ee9bf1bfb9e377322af81a69` | BSD-2-Clause |
| `tarballs/dav1d-1.5.4.tar.xz` | https://downloads.videolan.org/pub/videolan/dav1d/1.5.4/dav1d-1.5.4.tar.xz (signature: `.asc` next to it) | `686616b7c69eb88d44459391ab25cac13b6647a3b288835c5784e71c1514a5c5` | BSD-2-Clause |
| `tarballs/ffmpeg-kit-next-8.1.1.tar.gz` | https://github.com/arthenica/ffmpeg-kit-next/archive/refs/tags/v8.1.1.tar.gz (only `apple/src/fftools/`, `apple/src/ffmpeg_context.[ch]`, `apple/src/stdbit.h` are used) | `9afcf3422921e67c7cf0950940509bc956d79fd311d3ac3592ba10fe6cfd3787` | LGPL-3.0-or-later |

`changes.diff`: the patches applied to FFmpeg's release tarball (`patch -p1`, by the build script), each dated and explained in `scripts/patches/README.md`; zimg, OpenH264 and dav1d are unmodified.
The only modified FFmpeg files are the `fftools/` sources as FFmpegKitNext
publishes them (their modification history is at the top of each file), used
unchanged; Collaj's own glue is `scripts/bridge/native/collaj_ffmpeg.c` and
`collaj_ffmpeg.h`.

## 3. How it was built

`scripts/build_ffmpeg_ios.sh` (with `scripts/configure_flags.txt` and
`scripts/tools/pkg-config-shim.sh`) is the complete build: on a Mac with the
Xcode listed in `toolchain.txt`,

```sh
cd scripts
MIRROR_DIR=../tarballs FFTOOLS=1 ./build_ffmpeg_ios.sh
```

rebuilds every framework above as `out/xcframeworks/*.xcframework`
(iPhone arm64 and simulator arm64; add `ios-x86_64-simulator` to `SLICES` for
an Intel Mac), minimum iOS 16.0. dav1d is built with meson and ninja,
which the script pip-installs at pinned versions (SHA-256-checked wheels:
meson 1.11.2, ninja 1.13.2) into a venv of Xcode's python3; like the Xcode
toolchain, they are generally available build tools used unmodified, not part
of the Corresponding Source.
`configure_flags.txt` lists every enabled component with the reason it is
there. The only per-machine inputs are the Xcode toolchain and SDK (system
tools, not part of the Corresponding Source); build paths are mapped to
`/collaj-ffmpeg-build` so they do not depend on the machine.

## 4. Replacing or modifying the libraries

The app talks to these frameworks only through dynamic linking:

* to FFmpeg through its public C API (the exported symbols of the six `lib*`
  frameworks: `avformat_open_input`, `av_log_set_callback`, …);
* to `fftools.framework` through the eight functions of
  `scripts/bridge/native/collaj_ffmpeg.h`.

A modified, interface-compatible build (same major versions: libavutil 60,
libavcodec 62, libavformat 62, libavfilter 11, libswscale 9, libswresample 6;
same install names `@rpath/<name>.framework/<name>`) produced with the script
can replace the corresponding `Frameworks/<name>.framework/<name>` binaries in
the application bundle; the bundle must then be re-signed with the user's own
signing identity to be installed on a device. This is the shared-library
route of LGPL-2.1 §6(b) and LGPL-3.0 §4(d)(1): at run time the app uses the
copy of each library in its bundle, and it works with a modified,
interface-compatible version put in its place.

Collaj's terms do not prohibit reverse engineering of the application for
debugging such modifications (section “Open-Source Software” of the Terms of
Use, in the app under Settings › About › Terms of use, in each of its
languages; Apple’s standard licence agreement, under which the App Store
distributes the app, also leaves open-source components to their own licences).

## 5. Texts

`COPYING.LGPLv2.1`, `COPYING.LGPLv3` and `COPYING.GPLv3` are in the FFmpeg
tarball; zimg's `COPYING`, OpenH264's `LICENSE` and dav1d's `COPYING`
(BSD-2-Clause) in theirs; copies are in `licenses/`. `NOTICES_ffmpeg.txt`
gathers them in the format of the app's `licenses/ffmpeg_libraries.txt`
(entries FFmpeg, fftools/FFmpegKitNext, zimg, OpenH264, dav1d), which is what
the app shows in Settings › About › Licences.

Contact for source requests: collaj.app@proton.me (Arnaud Desné EI).
